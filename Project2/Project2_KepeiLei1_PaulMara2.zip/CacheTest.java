import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

/**
 * Code to test an <tt>LRUCache</tt> implementation.
 */
public class CacheTest {
	private DataProvider<Integer, Integer> provider;
	private static final int MAGIC_NUMBER = 101;
	
	@Before
	/**
	 * Instantiate a DataProvider with Integer 0 to 100. The key and the value are the same for
	 * testing convenience 
	 */
	public void setUp () {
		provider = new TestProvider<Integer,Integer>();
		for (int i = 0; i < MAGIC_NUMBER; i++) {
			((TestProvider<Integer, Integer>) provider).put(i,i);
		}
	}
	
	/**
	 * Test if the cache returns the right value, no matter the data is from cache or from
	 * the provider
	 */
	@Test
	public void returnsRightValue () {
		DataProvider<Integer,Integer> provider = this.provider;
		Cache<Integer,Integer> cache = new LRUCache<Integer,Integer>(provider, 5);
		assertEquals(cache.get(9), (Integer) 9);
		assertEquals(cache.get(20), (Integer) 20);
		assertEquals(cache.get(9), (Integer) 9);
	}
	
	/**
	 * Test if the cache takes the value from the right place. aka: a cache should grab the value
	 * if the value is in the cache. An int is instantiated to keep track of the number of times grabbing
	 * data from the provider manually. In the end, the missNum, cache.getNumMisses(), and provider.getCalledTime()
	 * should equal to each other
	 */
	@Test
	public void implementTheCacheCorrect () {
		DataProvider<Integer,Integer> provider = this.provider;
		Cache<Integer,Integer> cache = new LRUCache<Integer,Integer>(provider, 5);
		int missNum = 0;
		// All new entries, thus three accumulator should equal to 5 at the end;
		cache.get(25);
		cache.get(33);
		cache.get(45);
		cache.get(9);
		cache.get(20);
		missNum += 5;  // 5 values are grabbed from the provider
		assertTrue(missNum == cache.getNumMisses() && missNum == ((TestProvider<Integer, Integer>) provider).getCalledTime());
		cache.get(20);
		cache.get(25);
		cache.get(99);  // 33 is evicted at this point
		cache.get(33);  // the cache now has 9,20,25,99,33
		missNum += 2; // 2 values are grabbed from the provider
		assertTrue(missNum == cache.getNumMisses() && missNum == ((TestProvider<Integer, Integer>) provider).getCalledTime());
		cache.get(9); 
		cache.get(20);
		cache.get(25);
		cache.get(99);
		cache.get(33); // no values are grabbed from the provider
		assertTrue(missNum == cache.getNumMisses() && missNum == ((TestProvider<Integer, Integer>) provider).getCalledTime());
	}
}
