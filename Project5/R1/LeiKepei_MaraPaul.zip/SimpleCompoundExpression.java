
public abstract class SimpleCompoundExpression extends AbstractCompoundExpression {

}
